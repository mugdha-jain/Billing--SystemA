package com.capgemini.Practicedemo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.Practicedemo.dto.Shipwreck;
@Repository
@Transactional
public class ShipwreckRepositoryImpl implements ShipwreckRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public List<Shipwreck> list() {
		Query query=entityManager.createQuery("select wreck from Shipwreck wreck");
		return query.getResultList();
	}

	@Override
	public Shipwreck create(Shipwreck wreck) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck get(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck update(Long id, Shipwreck wreck) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck delete(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
