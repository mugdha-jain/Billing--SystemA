package com.eg.democar.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eg.democar.dto.CarDTO;
@Repository
@Transactional
public class CarDAOImpl implements CarDAO{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub

		Query query = entityManager.createQuery(
				"select car from CarDTO car");
		
				return query.getResultList();
	
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		return (CarDTO)entityManager.find(CarDTO.class, id);
	}

	@Override
	public CarDTO create(CarDTO car) {
		// TODO Auto-generated method stub
		System.out.println("putting wreck");
		entityManager.persist(car);
		
		return car;

	}

	@Override
	public CarDTO update(CarDTO car) {
		// TODO Auto-generated method stub
		return entityManager.merge(car);
	}

	@Override
	public CarDTO delete(int id) {
		// TODO Auto-generated method stub
		CarDTO s=(CarDTO)entityManager.find(CarDTO.class, id);
		entityManager.remove(s);
		return s;
	}

	
}
