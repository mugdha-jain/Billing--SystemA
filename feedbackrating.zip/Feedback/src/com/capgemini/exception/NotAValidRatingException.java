package com.capgemini.exception;

public class NotAValidRatingException extends Exception{

}
