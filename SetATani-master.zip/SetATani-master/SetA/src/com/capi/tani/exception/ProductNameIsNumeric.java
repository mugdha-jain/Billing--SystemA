package com.capi.tani.exception;

public class ProductNameIsNumeric extends Exception{

	@Override
	public String toString() {
		return "ProductNameIsNumeric ";
	}
	

}
