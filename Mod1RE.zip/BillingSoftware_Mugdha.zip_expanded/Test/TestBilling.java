import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.salaesmanagement.bean.Sale;
import com.capgemini.salaesmanagement.service.ISaleService;
import com.capgemini.salaesmanagement.service.SaleService;
import com.capgemini.sales.exception.ProductNameIsnumeric;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class TestBilling {

	ISaleService ref=new SaleService();
	@Before
	public void bef()
	{
		
	}
	
	@Test
	public void test1() throws ProductNameIsnumeric {
    ref.insertSalesDetails(new Sale(1001,1001," Electronics","TV",LocalDate.now(),2,3000,"elect.device",1500));
		}
	
	@Test
	public void test2() throws ProductNameIsnumeric {
	    ref.insertSalesDetails(new Sale(1001,1001," Electronics","TV",LocalDate.now(),2,3000,"elect.device",1500));
			}

}
