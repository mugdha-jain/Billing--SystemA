package com.cg.product.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exception.InvalidNameException;
import com.cg.product.pojo.ProductDto;
import com.cg.product.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired(required=true)
	ProductRepo productrepo;
	public List<ProductDto> findAll(){
		return productrepo.findAll() ;	
	}
	public ProductDto create(ProductDto productdto) {
		String nm=productdto.getpName();
		Pattern pattern=Pattern.compile("^[A-Za-z]*$");
		Matcher mat=pattern.matcher(nm);
		boolean b=mat.find();
		if(b==false)
			throw new InvalidNameException();
		return productrepo.create(productdto);
	}
	public ProductDto get(int id) {
		return productrepo.get(id);
	}
	public ProductDto update(int id,ProductDto productdto) {
		return productrepo.update(id, productdto);
		
	}
	public ProductDto delete(int id) {
		return productrepo.delete(id);
		
	}
}
