package com.eg.democar.service;

import java.util.List;

import com.eg.democar.dto.CarDTO;

public interface ServiceCar {

	  public List<CarDTO> findAll(); 
	    public CarDTO findById(int id);
	    public CarDTO create(CarDTO car);
	    public CarDTO update(CarDTO car);
	    public CarDTO delete(int id);
}
