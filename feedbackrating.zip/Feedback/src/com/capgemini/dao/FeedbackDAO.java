package com.capgemini.dao;


import java.util.HashMap;

import com.capgemini.trainer.Trainer;
import com.capgemini.util.DBUtil;

public class FeedbackDAO implements IFeedbackDAO{

	
	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		DBUtil.feedbackList.put(trainer.getId(),trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
      return DBUtil.feedbackList;
		
	}

}
