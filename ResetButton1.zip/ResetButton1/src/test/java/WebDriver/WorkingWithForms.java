package WebDriver;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms {

	public static void main(String[] args) 
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","D:\\Users\\TANAGRAW\\Desktop\\taneesha\\module 3\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/WorkingWithForms.html");
	
		try {
			//Find username textbox and enter value
			driver.findElement(By.id("txtUserName")).sendKeys("Taneesha");
			
			//Find password textbox and enter value
			driver.findElement(By.name("txtPwd")).sendKeys("asdf");
//		Thread.sleep(1000);
			
			//Find confirm password textbox and enter value
			driver.findElement(By.className("Format")).sendKeys("asdf");
//				Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("some Exception");
		}
				
		//Find first Name textbox and enter value
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Taneesha");
	
		//Find last Name textbox and enter value
				driver.findElement(By.name("txtLN")).sendKeys("Agrawal");
	
				//Find gender ratio button and enter value
				driver.findElement(By.cssSelector("input[value='Female']")).click();
	
				//Find Date of Birth textbox and enter value
				driver.findElement(By.name("DtOB")).sendKeys("07/28/1998");
	
				//Find email textbox and enter value
				driver.findElement(By.name("Email")).sendKeys("Taneesha.agrawal@gamil.com");
	
				//Find Address textbox and enter value
				driver.findElement(By.name("Address")).sendKeys("Agrawal Market,Barnahal");
	
				Select dropCity= new Select(driver.findElement(By.name("City")));
				//dropCity.selectByVisibleText("Mumbai");
				dropCity.selectByIndex(1);
				
						
                //Find phone textbox and enter value
				driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("7830447679");
				
				//find hobby ratio button and click the button
		//driver.findElement(by.xpath("html/body/form/table/tbody/tr[12]/td[2]"));
				driver.findElement(By.cssSelector("input[value='Reading']")).click();
//	            List<WebElement> element=driver.findElement(By.name("chkHobbies"));
	
				
	driver.findElement(By.name("reset")).click();
	}
}
	
				
