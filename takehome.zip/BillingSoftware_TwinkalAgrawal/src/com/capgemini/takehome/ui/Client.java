package com.capgemini.takehome.ui;

import java.util.Scanner;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {

	public static void main(String[] args) {

		IProductService serRef = new ProductService();
		while (true) {
			// Displaying menu to the Cashier
			System.out.println("1: Generate Bill by entering Product and quantity");
			System.out.println("2:Exit");
			Scanner sc = new Scanner(System.in);
			int n = Integer.parseInt(sc.next());

			if (n == 1) {
				System.out.println("Enter Product details");
				System.out.println("Enter the product code: ");
				Scanner sc1 = new Scanner(System.in);
				String pcode = sc1.next();
				System.out.println("Enter the Quntity: ");
				int pquntity = Integer.parseInt(sc1.next());

				// Checking whether the product code is valid or not
				if (pcode.length() <= 3) {
					System.out.println("Enter the valid Product Code");
				}
				// Checking whether the quantity value is valid or not
				else if (pquntity <= 0)
					System.out.println("Enter the valid Quantity");
				// Checking whether product code is available or not
				else {
					int code = Integer.parseInt(pcode);
					Product pRef;
					pRef = serRef.getProductDetails(code);
					if (pRef == null)
						System.out.println("Sorry! The Product Code" + code + "is not available");
					// Calculating Total and displaying the bill
					else {
						System.out.println("Product Name: " + pRef.getPname());
						System.out.println("Product Category: " + pRef.getPcategory());
						System.out.println("Product Description :" + pRef.getDescription());
						System.out.println("Product Price(Rs): " + pRef.getPrice());
						System.out.println("Quantity :" + pquntity);
						System.out.println("Line Total(Rs): " + pquntity * pRef.getPrice());
					}

				}

				// If User chooses the option exit
			} else if (n == 2)
				System.exit(0);

			// If the option entered by user is unavailable
			else
				System.out.println("Please Enter Correct Choice");

		}

	}

}
