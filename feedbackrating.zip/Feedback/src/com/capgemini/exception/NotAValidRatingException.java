package com.capgemini.exception;

public class NotAValidRatingException extends Exception{

	public NotAValidRatingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
