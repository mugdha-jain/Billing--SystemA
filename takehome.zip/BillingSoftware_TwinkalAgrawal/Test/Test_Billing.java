import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public class Test_Billing {

	private IProductDAO pdaoRef;

	@Before
	public void tearDown() throws Exception {
		pdaoRef = new ProductDAO();
	}
	//Testing the method of class ProductDAO 
	@Test
	public void test() {
		Product pRef;
		boolean flag;
		pRef = pdaoRef.getProductDetails(1001);
		if (pRef == null)
			flag = false;
		else
			flag = true;
		assertTrue(flag);
		pRef = pdaoRef.getProductDetails(1001);
		if (pRef == null)
			flag = false;
		else
			flag = true;
		assertTrue(flag);
	}

	@After
	public void end() {
		pdaoRef = null;
	}

}
