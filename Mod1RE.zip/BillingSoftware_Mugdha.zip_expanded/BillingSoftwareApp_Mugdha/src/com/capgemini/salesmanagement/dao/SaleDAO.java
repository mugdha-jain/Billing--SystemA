package com.capgemini.salesmanagement.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.capgemini.salaesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO  {

	//private HashMap<Integer,Sale> salesDetails=new HashMap<>();
			
/*	
	public SaleDAO()
	{  salesDetails = new HashMap<>();

	Sale sale1 = new Sale();
	sale1.getSaleId();
	sale1.setProdCode(1001);
	sale1.setCategory("Electronics");
	sale1.setSaleDate(LocalDate.now());
	sale1.setQuantity(2);
	sale1.getLineTotal();
 salesDetails.put(sale1.getSaleId(),sale1);
*/
 
 

	public HashMap<Integer,Sale> insertSalesDetails(Sale sale)
	{ 
		CollectionUtil.sales.put(sale.getSaleId(), sale);
		return CollectionUtil.getCollection();
		}


		
	
	}


