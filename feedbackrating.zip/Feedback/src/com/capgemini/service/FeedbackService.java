package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.IFeedbackDAO;
import com.capgemini.trainer.Trainer;

public class FeedbackService implements IFeedbackService {

	IFeedbackDAO feedref=new FeedbackDAO();

	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		feedref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
		return feedref.getTrainerList();
	}
}
