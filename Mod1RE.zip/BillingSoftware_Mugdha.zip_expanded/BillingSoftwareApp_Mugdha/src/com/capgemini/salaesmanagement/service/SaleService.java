package com.capgemini.salaesmanagement.service;

import java.util.HashMap;

import com.capgemini.salaesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService{

 ISaleDAO s=new SaleDAO();
 String str="";
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		return s.insertSalesDetails(sale);
	
		
		
	}

	@Override
	public boolean validateProductCode(int productId) {
		if(productId==1001||productId==1002||productId==1003||productId==1004)
			return true;
		else
		return false;
	}

	@Override
	public boolean validateQuantity(int qty) {
		// TODO Auto-generated method stub
		if(qty>0 && qty<5)
			return true;
		else
		return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		// TODO Auto-generated method stub
		if(prodCat.equals("Electronics")||prodCat.equals("Toys"))
		{	str=prodCat;
		return true;
		}
		else 
			return false;
	}

	@Override
	public boolean validateProductName(String prodName) {
		// TODO Auto-generated method stub
		if(str.equals("Electronics"))
		{
			if(prodName.equals("TV")||prodName.equals("Smart Phone")||prodName.equals("Video Game"))
			return true;	
		}
		else if(str.equals("Toys"))
		{
			if(prodName.equals("Soft Toys")||prodName.equals("Telescope")||prodName.equals("barbee Doll"))
           return true;	
		}
		return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		if(price>200)
			return true;
		
		return false;
	}

	

	
}
