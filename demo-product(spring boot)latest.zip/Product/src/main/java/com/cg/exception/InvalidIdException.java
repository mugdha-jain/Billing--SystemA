package com.cg.exception;

public class InvalidIdException extends RuntimeException{

}
