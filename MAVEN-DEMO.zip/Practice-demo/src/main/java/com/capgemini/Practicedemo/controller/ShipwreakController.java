package com.capgemini.Practicedemo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Practicedemo.dto.Shipwreck;
import com.capgemini.Practicedemo.dto.ShipwreckStub;

@RestController
@RequestMapping("api/v1")
public class ShipwreakController {
	
	@RequestMapping(method=RequestMethod.GET,value="shipwrecks")
	public List<Shipwreck> list(){
		return ShipwreckStub.list();
	}
	@RequestMapping(method=RequestMethod.POST,value="shipwrecks")
	public Shipwreck save(@RequestBody Shipwreck shipwreck)
	{
		return ShipwreckStub.create(shipwreck);
	}
	@RequestMapping(method=RequestMethod.GET,value="shipwrecks/{id}")
	public Shipwreck get(@PathVariable(value="id")long id) {
		
		return ShipwreckStub.get(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="shipwrecks/{id}")
	public Shipwreck update(@RequestBody Shipwreck shipwreck,@PathVariable(value="id")long id) {
		
		return ShipwreckStub.update(id, shipwreck);
	}
	@RequestMapping(method=RequestMethod.DELETE,value="shipwrecks/{id}")
	public Shipwreck delete(@PathVariable(value="id")long id) {
		
		return ShipwreckStub.delete(id);
	}
	
}
