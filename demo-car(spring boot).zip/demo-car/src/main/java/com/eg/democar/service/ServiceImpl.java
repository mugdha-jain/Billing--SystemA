package com.eg.democar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eg.democar.dao.CarDAO;
import com.eg.democar.dto.CarDTO;


@Transactional
@Service
public class ServiceImpl implements ServiceCar {

	@Autowired
	CarDAO carref;
	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub
		return carref.findAll();
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		return carref.findById(id);
	}

	@Override
	public CarDTO create(CarDTO car) {
		// TODO Auto-generated method stub
		return carref.create(car);
	}

	@Override
	public CarDTO update(CarDTO car) {
		// TODO Auto-generated method stub
		return carref.update(car);
	}

	@Override
	public CarDTO delete(int id) {
		// TODO Auto-generated method stub
		return carref.delete(id);
	}

}
