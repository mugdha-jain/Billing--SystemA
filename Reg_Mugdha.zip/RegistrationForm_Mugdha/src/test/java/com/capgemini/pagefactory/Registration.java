package com.capgemini.pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	WebDriver driver;
	

	@FindBy(how = How.ID,  id = "usrID")
	@CacheLookup
	WebElement userId;
	
	@FindBy(how = How.NAME,name = "passid")
	@CacheLookup
	WebElement password;
	
	@FindBy(how = How.ID,id = "usrname")
	@CacheLookup
	WebElement name;
	
	@FindBy(how = How.ID,id = "addr")
	@CacheLookup
	WebElement address;
	
	@FindBy(how = How.NAME,name = "country")
	@CacheLookup
	WebElement country;
	
	@FindBy(how = How.NAME,name = "zip")
	@CacheLookup
	WebElement zipCode;
	
	@FindBy(how = How.NAME,name = "email")
	@CacheLookup
	WebElement emailId;
	
	@FindBy(how = How.NAME,name = "sex")
	@CacheLookup
	WebElement gender;
	
	@FindBy(how = How.CLASS_NAME, using = "en")
	@CacheLookup
	WebElement language;
	
	@FindBy(how = How.CLASS_NAME, using = "submit")
	@CacheLookup
	WebElement submit;
	
	public Registration(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

   public String getUserId() {
		return userId.getText();
	}

	public void setUserId(String suserId) {
		this.userId.sendKeys(suserId);
	}

	public String getPassword() {
		return password.getText();
	}

	public void setPassword(String spassword) {
		this.password.sendKeys(spassword);
	}

	public String getName() {
		return name.getText();
	}

	public void setName(String sname) {
		this.name.sendKeys(sname);
	}

	public String getAddress() {
		return address.getText();
	}

	public void setAddress(String saddress) {
		this.address.sendKeys(saddress);
	}

	public String getCountry() {
		return country.getText();
	}

	public void setCountry(String scountry) {
		Select dropCountry = new Select(country);
		dropCountry.selectByVisibleText(scountry);
	}

	public String getZipCode() {
		return zipCode.getText();
	}

	public void setZipCode(String szipCode) {
		this.zipCode.sendKeys(szipCode);
	}

	public String getEmailId() {
		return emailId.getText();
	}

	public void setEmailId(String semailId) {
		this.emailId.sendKeys(semailId);
	}

	public String getGender() {
		return gender.getText();
	}

	public void setGender(String gender) {
		this.gender = driver.findElement(By.xpath(gender));
		this.gender.click();
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage() {
		this.language.click();
	}
	
	public WebElement getSubmit() {
		return submit;
	}
	
	public void setSubmit() {
		this.submit.click();
	}



}
