import org.junit.jupiter.api.Test;

import com.capgemini.exception.NotAValidRatingException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.IFeedbackService;
import com.capgemini.trainer.Trainer;

class Testfeedback {

	IFeedbackService fs=new FeedbackService();
	
	
	
	//@Test(expected=com.capgemini.exception.NotAValidRatingException.class)
	@Test
	void test() throws NotAValidRatingException{
		Trainer t=new Trainer("Mugdha","JEE","1-02-2019","4-04-2019",5);
		fs.addFeedback(t);
		
	}
	@Test
	void test2() throws NotAValidRatingException
	{
		Trainer t1=new Trainer("Twinkal","JEE","1-02-2018","4-09-2018",5);
		fs.addFeedback(t1);
		fs.getTrainerList();
	}

}
