package com.capgemini.exception;

public class InsufficientWalletBalanceException extends Exception {

}
