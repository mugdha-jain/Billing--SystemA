package com.capgemini.sales.exception;

public class ProductNameIsnumeric extends Exception{
@Override
	public String toString()
	{
		return "ProductNameisNumeric";
		
	}
}
