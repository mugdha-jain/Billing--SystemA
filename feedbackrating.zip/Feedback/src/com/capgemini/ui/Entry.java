package com.capgemini.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.exception.NotAValidRatingException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.IFeedbackService;
import com.capgemini.trainer.Trainer;

public class Entry {

	public static void main(String[] args) throws NotAValidRatingException {
		IFeedbackService service=new FeedbackService();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ur choice: /n 1- Enter details /n 2-Exit");
        int choice=Integer.parseInt(sc.next());
        switch(choice)
        {
        case 1:
        	System.out.println("Enter Trainer name" );
        	String tname=sc.next();
        	System.out.println("Enter coursename");
        	String cname=sc.next();
        	System.out.println("Enter Start date");
        	String sdate=sc.next();
        	System.out.println("Enter end date");
        	String edate=sc.next();
        	System.out.println("Enter rating");
        	int rat=Integer.parseInt(sc.next());
        	if(rat>10)
        		throw new NotAValidRatingException("Rating is not valid");
     //   	int id = Integer.format("%04d", Math.random.nextInt(1000));

        	int feedid=(int) (Math.random()*1000);
        	Trainer tr=new Trainer(tname,cname,sdate,edate,rat);
        	tr.setId(feedid);
        	tr.setName(tname);
        	tr.setCourseName(cname);
        	tr.setStartDate(sdate);
        	tr.setEndDate(edate);
        	tr.setRating(rat);
        	service.addFeedback(tr);
        	
        	System.out.println("Enter feedback rating to be searched");
        	int frat=Integer.parseInt(sc.next());
            HashMap<Integer,Trainer> map=service.getTrainerList();
            for(Map.Entry<Integer,Trainer> var:map.entrySet()) {
            	if(var.getValue().getRating()==frat)
            	{   System.out.println("Feedback Id:"+" " +var.getKey());
            		System.out.println("Trainer name:"+" " +var.getValue().getName());
            		System.out.println("Course name:"+" "+var.getValue().getCourseName());
            		System.out.println("start date:"+" "+var.getValue().getStartDate());
            		System.out.println("End date:"+" "+var.getValue().getEndDate());
            		System.out.println("rating:"+" "+var.getValue().getRating());
            	}
   
            	            	
            	
            }
            break;
            	case 2:
            		System.exit(0);
            		
            	default:System.out.println("Enter correct choice");
            }
        System.out.println("No record found");
        	
        }
		
	}

